const readline=require('readline');

const getUserInput=() => {
  const rl=readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  return new Promise((resolve) => {
    rl.question('Enter the array elements separated by spaces: ', (input) => {
      const arr = input.split(' ').map((num) => parseInt(num));
      resolve(arr);
      rl.close();
    });
  });
};

module.exports={ getUserInput };