const express = require("express");
const bodyParser = require("body-parser");
const { getUserInput } = require("./userInput"); // Assuming the userInput.js file contains the function to get user input
const app = express();
app.use(bodyParser.json());
const port = 3000;

app.post("/bfhl", (req, res) => {
  const arr = req.body.arr;
  if (!Array.isArray(arr)) {
    res.status(400).json({ is_success: false, error: "Input should be an array" });
    return;
  }

  const even_numbers = arr.filter((num) => num % 2 === 0);
  const odd_numbers = arr.filter((num) => num % 2 !== 0);
  const alphabets = arr
    .filter((item) => typeof item === "string")
    .map((item) => item.toUpperCase());

  res.json({
    is_success: true,
    user_id: "john_doe_17091999", //placeholder
    email: "user@example.com",
    roll_number: "12345",
    odd_numbers: odd_numbers,
    even_numbers: even_numbers,
    alphabets: alphabets,
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});